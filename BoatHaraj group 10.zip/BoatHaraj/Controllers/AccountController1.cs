﻿using Microsoft.AspNetCore.Mvc;

namespace BoatHaraj.Controllers
{
    public class AccountController1 : Controller
    {
        public IActionResult Index()
        {
            ViewBag.sessionId = HttpContext.Session.GetString("id");
            ViewBag.sessionUserName =
            HttpContext.Session.GetString("username");
            return View();
        }
    }
}
