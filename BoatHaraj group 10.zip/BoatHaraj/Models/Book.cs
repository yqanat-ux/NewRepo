﻿namespace BoatHaraj.Models
{
    public class Book
    {
        public int id { get; set; }

        public string buyer { get; set; }
        public string renter { get; set; }
        public int boathours { get; set; }
        public string boattype { get; set; }



        public Book()
        {
            
        }



    }
}
